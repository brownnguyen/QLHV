var SinhVien = function (maSV,hoTen,email,soDT,cmnd,diemToan,diemLy,diemHoa) {
        this.MaSV = maSV;
        this.HoTen = hoTen;
        this.Email = email;
        this.SoDT = soDT;
        this.CMND = cmnd;
        this.DiemToan = diemToan;
        this.DiemLy = diemLy;
        this.DiemHoa = diemHoa;
}